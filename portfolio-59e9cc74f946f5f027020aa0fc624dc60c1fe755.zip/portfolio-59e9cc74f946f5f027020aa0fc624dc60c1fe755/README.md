# Portfolio - Carolina Seixas
Página pessoal que reúne os projetos que fiz, detalhes sobre mim e sobre minha formação

## Linguagens utilizadas
Página feita com HTML5 e CSS3.

## Versões
As versões são atualizadas conforme são adicionados mais projetos ao portfólio.

## Página atual
[Link para a última versão do site](https://carolinaseixas.github.io/portfolio/)
